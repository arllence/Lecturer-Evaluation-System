            function send() {
        
                    if(document.getElementById("section2a1").checked == false  && document.getElementById("section2a2").checked == false && document.getElementById("section2a3").checked == false && document.getElementById("section2a4").checked == false && document.getElementById("section2a5").checked == false){
                        // no checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2b1").checked == false  && document.getElementById("section2b2").checked == false && document.getElementById("section2b3").checked == false && document.getElementById("section2b4").checked == false && document.getElementById("section2b5").checked == false){
                        // no checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg2').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2c1").checked == false  && document.getElementById("section2c2").checked == false && document.getElementById("section2c3").checked == false && document.getElementById("section2c4").checked == false && document.getElementById("section2c5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg3').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2d1").checked == false  && document.getElementById("section2d2").checked == false && document.getElementById("section2d3").checked == false && document.getElementById("section2d4").checked == false && document.getElementById("section2d5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg4').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2e1").checked == false  && document.getElementById("section2e2").checked == false && document.getElementById("section2e3").checked == false && document.getElementById("section2e4").checked == false && document.getElementById("section2e5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg5').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2f1").checked == false  && document.getElementById("section2f2").checked == false && document.getElementById("section2f3").checked == false && document.getElementById("section2f4").checked == false && document.getElementById("section2f5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg6').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2g1").checked == false  && document.getElementById("section2g2").checked == false && document.getElementById("section2g3").checked == false && document.getElementById("section2g4").checked == false && document.getElementById("section2g5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg7').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2h1").checked == false  && document.getElementById("section2h2").checked == false && document.getElementById("section2h3").checked == false && document.getElementById("section2h4").checked == false && document.getElementById("section2h5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg8').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2i1").checked == false  && document.getElementById("section2i2").checked == false && document.getElementById("section2i3").checked == false && document.getElementById("section2i4").checked == false && document.getElementById("section2i5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg9').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2j1").checked == false  && document.getElementById("section2j2").checked == false && document.getElementById("section2j3").checked == false && document.getElementById("section2j4").checked == false && document.getElementById("section2j5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg10').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2k1").checked == false  && document.getElementById("section2k2").checked == false && document.getElementById("section2k3").checked == false && document.getElementById("section2k4").checked == false && document.getElementById("section2k5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg11').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section2l1").checked == false  && document.getElementById("section2l2").checked == false && document.getElementById("section2l3").checked == false && document.getElementById("section2l4").checked == false && document.getElementById("section2l5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg12').innerHTML = msg;
                        return false;
                    }
                    // return true;                        
                }              
            
                function reset_msg() {
                    document.getElementById('msg').innerHTML = '';
                    document.getElementById('msg2').innerHTML = '';
                    document.getElementById('msg3').innerHTML = '';
                    document.getElementById('msg4').innerHTML = '';
                    document.getElementById('msg5').innerHTML = '';
                    document.getElementById('msg6').innerHTML = '';
                    document.getElementById('msg7').innerHTML = '';
                    document.getElementById('msg8').innerHTML = '';
                    document.getElementById('msg9').innerHTML = '';
                    document.getElementById('msg10').innerHTML = '';
                    document.getElementById('msg11').innerHTML = '';
                    document.getElementById('msg12').innerHTML = '';
            }

                function send2() {
                   
                    if(document.getElementById("section3a1").checked == false  && document.getElementById("section3a2").checked == false && document.getElementById("section3a3").checked == false && document.getElementById("section3a4").checked == false && document.getElementById("section3a5").checked == false){
                        // no checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section3b1").checked == false  && document.getElementById("section3b2").checked == false && document.getElementById("section3b3").checked == false && document.getElementById("section3b4").checked == false && document.getElementById("section3b5").checked == false){
                        // no checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg2').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section3c1").checked == false  && document.getElementById("section3c2").checked == false && document.getElementById("section3c3").checked == false && document.getElementById("section3c4").checked == false && document.getElementById("section3c5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg3').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section3d1").checked == false  && document.getElementById("section3d2").checked == false && document.getElementById("section3d3").checked == false && document.getElementById("section3d4").checked == false && document.getElementById("section3d5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg4').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section3e1").checked == false  && document.getElementById("section3e2").checked == false && document.getElementById("section3e3").checked == false && document.getElementById("section3e4").checked == false && document.getElementById("section3e5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg5').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section3f1").checked == false  && document.getElementById("section3f2").checked == false && document.getElementById("section3f3").checked == false && document.getElementById("section3f4").checked == false && document.getElementById("section3f5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg6').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section3g1").checked == false  && document.getElementById("section3g2").checked == false && document.getElementById("section3g3").checked == false && document.getElementById("section3g4").checked == false && document.getElementById("section3g5").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg7').innerHTML = msg;
                        return false;
                    }
                    // return true;                        
                }              
            

            function send3() {
    
                    if(document.getElementById("section1a1").checked == false  && document.getElementById("section1a2").checked == false){
                        // no checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section1b1").checked == false  && document.getElementById("section1b2").checked == false){
                        // no checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg2').innerHTML = msg;
                        return false;
                    }else if(document.getElementById("section1c1").checked == false  && document.getElementById("section1c2").checked == false){
                        // not checked
                        var msg = '<span style="color:red;">Oops! You forgot to answer this!<br></span>';
                        alert("Please answer all the questions"); 
                        document.getElementById('msg3').innerHTML = msg;
                        return false;
                    }
                    // return true;        s                
                }              
        
