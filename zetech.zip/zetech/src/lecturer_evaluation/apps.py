from django.apps import AppConfig


class LecturerEvaluationConfig(AppConfig):
    name = 'lecturer_evaluation'
